package com.hw3.homework3magic8ball;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity implements SensorEventListener {


    static public SensorManager mSensorManager;
    public List<Sensor> SensorList;
    private ImageView ballIV;
    private TextView answerTV;
    boolean sToggledL = false;
    long timestamp;

    private String[] answersArray = {"It is certain", "It is decided to be so", "Without a doubt", "Yes, definitely", "You may rely on it", "As I see it, yes",
            "Most likely", "Outlook good", "Yes", "Signs point to yes", "Reply hazy try again", "Ask again later",
            "Better not tell you now", "Cannot predict now", "Concentrate and ask again", "Don't count on it",
            "My reply is no", "My sources say no", "Outlook not so good", "Certainly not"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        SensorList = mSensorManager.getSensorList(Sensor.TYPE_ALL);

        ballIV = findViewById(R.id.magic_ball);

        answerTV = findViewById(R.id.answer);
    }


    @Override
    protected void onPause() {
        super.onPause();

        for ( int i = 0; i < SensorList.size(); i++ )
            mSensorManager.unregisterListener(this, SensorList.get(i) );
    }

    @Override
    protected void onResume() {
        super.onResume();
        for ( int i = 0; i < SensorList.size(); i++ )
            if ( SensorList.get(i).getType() == Sensor.TYPE_LIGHT )
                mSensorManager.registerListener(this, SensorList.get(i), 500000);
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        float sensVal = event.values[0];
        if ( event.sensor.getType() == Sensor.TYPE_LIGHT && sensVal < 100 && !sToggledL ) {
            timestamp = event.timestamp;
            sToggledL = true;
        } else if ( event.sensor.getType() == Sensor.TYPE_LIGHT && sensVal > 100 && sToggledL ) {

//            Calendar thatDay = Calendar.getInstance();
//            thatDay.set(event.timestamp);
//            Calendar today = Calendar.getInstance();
            long timestamp2 = event.timestamp;
            int diff = (int) ((timestamp2 - timestamp) % answersArray.length);
            sToggledL = false;
            answersArrayGen(diff);
        }

    }

    public void answersArrayGen(int diff){
        answerTV.setText(answersArray[diff]);

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

}
